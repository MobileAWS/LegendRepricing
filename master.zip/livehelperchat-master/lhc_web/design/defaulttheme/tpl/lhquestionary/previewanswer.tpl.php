<h2><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('questionary/previewanswer','Preview the answer');?></h2>
<p><?php echo erLhcoreClassBBCode::make_clickable(htmlspecialchars($answer->answer))?></p>
<br>
