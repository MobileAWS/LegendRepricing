<img src="<?php echo erLhcoreClassDesign::design('images/general/logo.png');?>" alt="Live Helper Chat" title="Live Helper Chat" />

<h1>Installation was completed</h1>

<div class="panel">
<p>Installation is complete. You can start by adding users and departments.

<a href="<?php echo erLhcoreClassDesign::baseurl('user/login')?>">Login here</a>
</p>
<br>
</div>
