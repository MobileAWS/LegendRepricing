<div role="alert" class="alert alert-success alert-dismissible fade in">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
<?php echo $msg?>
</div>

