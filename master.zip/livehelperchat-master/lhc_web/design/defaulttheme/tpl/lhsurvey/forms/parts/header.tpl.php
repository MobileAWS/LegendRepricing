<div class="row">
	<div class="col-xs-9">
		<div>
			<h4 class="fs16"><b><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('survey/fill','Please complete this short evaluation survey'); ?></b></h4>
		</div>
	</div>
	<div class="col-xs-3 mb5">	
		<?php include(erLhcoreClassDesign::designtpl('lhchat/customer_user_settings.tpl.php'));?>
	</div>
</div>