<?php 
/**
 * Include something fancy after an chat tabs
 * 
 * */
?>