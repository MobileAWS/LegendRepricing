<?php if (isset($show_demo) && $show_demo == true) : ?>
<div>
   <div class="message-row response" id="msg-10459" data-op-id="0"><div class="msg-date">10:14:39</div><span class="usr-tit vis-tit" role="button"><i class="material-icons chat-operators mi-fs15 mr-0">face</i>Visitor</span> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
   <div class="message-row message-admin operator-changes" id="msg-10463" data-op-id="1">
   <div class="msg-date">10:18:22</div><span class="usr-tit op-tit"><i class="material-icons chat-operators mi-fs15 mr-0">account_box</i>Operator</span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
</div>
<?php endif;?>