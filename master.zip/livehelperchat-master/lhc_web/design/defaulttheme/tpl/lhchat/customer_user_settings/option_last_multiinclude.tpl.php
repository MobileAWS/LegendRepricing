<?php 
/**
 * Custom menu item example
 * 
 * <li><a href="#" class="material-icons mat-100 mr-0" title="<?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chat/user_settings','Enable/Disable sound about new messages from the operator');?>"><?php $soundMessageEnabled == 0 ? print 'volume_off' : print 'volume_up'?></a></li>
 * */
?>