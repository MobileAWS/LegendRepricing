<div class="form-group">
<?php include(erLhcoreClassDesign::designtpl('lhchat/part/action_block.tpl.php')); ?>

<?php include(erLhcoreClassDesign::designtpl('lhchat/part/below_action_block.tpl.php')); ?>
</div>