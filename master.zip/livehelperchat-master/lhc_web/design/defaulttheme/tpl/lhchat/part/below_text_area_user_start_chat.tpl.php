<?php 
/**
 * Below text area in start chat form
 */
?>