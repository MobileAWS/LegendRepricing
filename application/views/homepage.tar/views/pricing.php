<?php include_once('header.php'); ?>
<?php include_once('nav-inner.php'); ?>
<article>
	<div class="container">
			<h1>Pricing</h1>
			<p>The Best Repricing software on the market from a firm that listens to its customers. Capture market share and profits now you can have both volume and profits.
            </p>
			<p>Remove eBay, Rakuten, Magento, and Web Analytics. Should have About us, Product Help  should lead to FAQ page.</p>
			<p>CREATE A Blog page. With simple intro for now. Stating: Legend Repricing is the best repricing software on the web, it works while you sleep because we work while you sleep. We are constantly refining our repricing algorithms so that you win the sales day and night, rain or shine. So if we fall behind on this blog know this it is because we are working extra super (insert expletive) hard on making sure you win the sales! Have a suggestion or feature? Chat with us or email us, we will implement as many features as fast as we can. We want you to succeed beyond your wildest dreams
.</p>
	</div>
</article>
<?php include_once('footer.php'); ?>