<?php include_once('header.php'); ?>
<?php include_once('nav-inner.php'); ?>
<article>
	<div class="container">
			<h1>Repricing Features</h1>
			<h6>Automatically Reprices Your items to keep you competitive.</h6>	
			<p>Repricing Worth Trying (change the people picture  to  a star shaped special offer type Blue Banner with white text stating 3 Months Free Trial!). We are also available on CHAT and look forward to hearing your suggestions as "We are the repricing company that listens."</p>
			<p>We are so sure you will absolutely LOVE our repricing system that we are giving a hefty, generous 3 MONTH FREE TRIAL.</p>
			<p>Second Repricing worth trying section CHANGE TO: <strong>Know where you stand:</strong> quickly see where you rank in price and whether you have the buybox.</p>
			<h6>Inventory Mangement:</h6>
			<p>Low inventory alerts via desktop system and soon a dedicated messaging app that will alert you when your account is low on inventory.</p>
			<p>*Basic repricing package, 50 dollars a month, hourly repricing, 10,000 items on one marketplace, subject to change without notice.</p>
	</div>
</article>
<?php include_once('footer.php'); ?>