<footer>
	<div class="container">
		<div class="btn-backTotop"> <a href="#home" title="Back To Top"><i class="fa fa-chevron-up"></i>top</a> </div>
		<div class="row box-footer">
			<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5 box-aboutUs">
				<h6>legend repricing</h6>
				<p>The Best Repricing software on the market from a firm that listens to its customers. Capture market share and profits now you can have both volume and profits.</p>
			</div>
			<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
				<ul class="list-footermenu">
					<li><a href="<?=base_url();?>about" title="About Us">About us</a></li>
					<li><a href="<?=base_url();?>home/faq" title="faq">Faq</a></li>
					<li><a href="<?=base_url();?>contact" title="About Us">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="footer-copyright">
		<div class="container">
			<p>copyright &copy; Legend Repricing <?php echo date('Y'); ?></p>
		</div>
	</div>
	</div>
</footer>
<script type="text/javascript" language="javascript" src="<?=base_url();?>/asset/js_d/jquery.flexslider-min.js"></script> 
<script type="text/javascript" language="javascript" src="<?=base_url();?>/asset/js_d/bootstrap/bootstrap.min.js"></script> 
<script type="text/javascript" language="javascript" src="<?=base_url();?>/asset/js_d/html5shiv.js"></script> 
<script type="text/javascript" language="javascript" src="<?=base_url();?>/asset/js_d/custom.js"></script>
</body>
</html>
