<?php include_once('header.php'); ?>
<?php include_once('nav-inner.php'); ?>
<article>
	<div class="container">
			<h1>Inventory Management</h1>
			
			<p>Avoid frustrating stock-outs and overselling. With centralized inventory, you can automatically sync inventory levels across your online store, marketplace (Amazon, eBay), and POS.</p>
			<p>*Basic repricing package, 50 dollars a month, hourly repricing, 10,000 items on one marketplace, subject to change without notice.</p>
	</div>
</article>
<?php include_once('footer.php'); ?>