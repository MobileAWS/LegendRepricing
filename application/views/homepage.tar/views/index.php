
	<?php include_once('header.php'); ?>
	<?php include_once('nav.php'); ?>
	<article>
	<ul class="bg-evnOdd">
		<li>
			<div class="container">
				<div class="box-welcome">
					<h1>Command the Marketplaces
						<p>Legend pricing is the most popular multi marketplace and buybox winning solution</p>
					</h1>
					<div class="row">
						<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4"> <span class="icon-basket"></span>
						<!--	<h2>Lorem Ipsum simply</h2>
							<p>Contrary to popular belief, Lorem Ipsum<br>
								is not simply random text.</p>-->
						</div>
						<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4"> <span class="icon-home icon-basket"></span>
						<!--	<h2>Lorem Ipsum simply</h2>
							<p>Contrary to popular belief, Lorem Ipsum<br>
								is not simply random text.</p>-->
						</div>
						<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4"> <span class="icon-card icon-basket"></span>
						<!--	<h2>Lorem Ipsum simply</h2>
							<p>Contrary to popular belief, Lorem Ipsum<br>
								is not simply random text.</p>-->
						</div>
					</div>
				</div>
			</div>
		</li>
		<li>
			<div class="container">
				<div class="row">
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"> <img src="<?=base_url();?>/asset/images_d/img-moniter-2.png" alt="" title=""/> </div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<h1>Repricing Features</h1>
						<h6>Automatically Reprices Your items to keep you competitive.</h6>
						<p>Systematic repricing that prevents price wars while maximizing volume and profits. 
							Our sophisticated pricing algorithms combined with machine learning will put you on top of the competition while you focus on building your business and your beauty sleep, 
							our systems work for you 24/7 for less than 2 dollars a day*.</p>
						<p>Repricing Worth Trying (change the people picture  to  a star shaped special offer type Blue Banner with white text stating 3 Months Free Trial!). 
							We are also available on CHAT and look forward to hearing your suggestions as “We are the repricing company that listens.”</p>
						<p>We are so sure you will absolutely LOVE our repricing system that we are giving a hefty, generous 3 MONTH FREE TRIAL.</p>
						<p>Second Repricing worth trying section CHANGE TO: Know where you stand: quickly see where you rank in price and whether you have the buybox.</p>

						<a href="<?=base_url();?>repricingfeatures" title="Learn More" class="btn">Learn More<i class="fa fa-angle-double-right"></i> </a> </div>
				</div>
			</div>
		</li>
		<!--<li>
			<div class="container">
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<h1>Repricing worth trying</h1>
						<p>Outsmart the competition and never lose the buy box again. With our Amazon repricing tool, you can set tailored options such as product condition, seller ranking, time of day, and much more.</p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
						<a href="<?=base_url();?>home/repricing" title="Learn More" class="btn">Learn More<i class="fa fa-angle-double-right"></i> </a> </div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 alRight"> <img src="<?=base_url();?>/asset/images_d/img-moniter-4.png" alt="" title=""/> </div>
				</div>
			</div>
		</li>-->
		<li>
			<div class="box-parallax-img">
				<div class="container">
					<div class="row">
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"> <img src="<?=base_url();?>/asset/images_d/img-moniter-1.png" alt="" title=""/> </div>
						<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
							<h1>Legend Repricing</h1>
							<p>The Best Repricing software on the market from a firm that listens to its customers. Capture market share and profits now you can have both volume and profits.</p>
							<p>Remove eBay, Rakuten, Magento, and Web Analytics. Should have About us, Product Help  should lead to FAQ page.</p>
							<p>CREATE A Blog page. With simple intro for now. Stating: Legend Repricing is the best repricing software on the web, it works while you sleep because we work while you sleep. We are constantly refining our repricing algorithms so that you win the sales day and night, rain or shine. So if we fall behind on this blog know this it is because we are working extra super (insert expletive) hard on making sure you win the sales! Have a suggestion or feature? Chat with us or email us, we will implement as many features as fast as we can. We want you to succeed beyond your wildest dreams.</p>

							<a href="<?=base_url();?>legendrepricing" title="Learn More" class="btn">Learn More<i class="fa fa-angle-double-right"></i></a> </div>
					</div>
				</div>
			</div>
		</li>
		<li>
			<div class="container">
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<h1>Inventory Management</h1>
						<p>Avoid frustrating stock-outs and overselling. With centralized inventory, you can automatically sync inventory levels across your online store, marketplace (Amazon, eBay), and POS.</p>
						<p>*Basic repricing package, 50 dollars a month, hourly repricing, 10,000 items on one marketplace, subject to change without notice.</p>
						<a href="<?=base_url();?>inventory" title="Learn More" class="btn">Learn More<i class="fa fa-angle-double-right"></i></a> </div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 alRight"> <img src="<?=base_url();?>/asset/images_d/img-moniter-3.png" alt="" title="" /> </div>
				</div>
			</div>
		</li>
	</ul>
</article>

	<?php include_once('footer.php'); ?>

