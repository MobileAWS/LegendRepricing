<?php include_once('header.php'); ?>
<?php include_once('nav-inner.php'); ?>
<article>
    <div class="container">
        <h1>Faq</h1>
				<div class="panel-group" id="accordion">
						<div class="panel panel-default">
								<div class="panel-heading">
										<h4 class="panel-title">
												<a href="#collapseOne" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">Can I set a minimum price?</a>
										</h4>
								</div>
								<div class="panel-collapse collapse" id="collapseOne">
										<div class="panel-body">
												<p>Absolutely. In fact you MUST. You are required to set a minimum price (floor) below which you would not like to lower.  We will never go below your set minimum price.</p>
										</div>
								</div>
						</div>
						<div class="panel panel-default">
								<div class="panel-heading">
										<h4 class="panel-title">
												<a href="#collapseSecond" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle">
														Can I set a maximum price?
												</a>
										</h4>
								</div>
								<div class="panel-collapse collapse in" id="collapseSecond">
										<div class="panel-body">
												<p>Yes. Indeed you must. We will never go above this price.</p>
										</div>
								</div>
						</div>
						<div class="panel panel-default">
								<div class="panel-heading">
										<h4 class="panel-title">
												<a href="#collapsethree" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
													Can I set an MAP price?
												</a>
										</h4>
								</div>
								<div class="panel-collapse collapse" id="collapsethree">
										<div class="panel-body">
												<p>Yes. We understand MAP agreements and if supported by the marketplace you may. We have implemented that feature</p>
										</div>
								</div>
						</div>
						<div class="panel panel-default">
								<div class="panel-heading">
										<h4 class="panel-title">
												<a href="#collapsefour" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
													Do you just lower my price to the minimum and leave it there?
												</a>
										</h4>
								</div>
								<div class="panel-collapse collapse" id="collapsefour">
										<div class="panel-body">
												<p>NO! Absolutely Not. We optimise your price so that you both make a PROFIT AND sell as much as possible. The pricing algorithms were developed by trained Economists, Statisticians, Computer Scientists  and Physicists.  We are a bunch of eggheads and proud of it.</p>
										</div>
								</div>
						</div>	
        </div>
    </div>									
</article>
<?php include_once('footer.php'); ?>