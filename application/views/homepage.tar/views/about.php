
<?php include_once('header.php'); ?>
<?php include_once('nav-inner.php'); ?>
<article>
    <div class="container">
    <h1>About us</h1>
    <p>Legend Repricing aims to implement the smartest algorithms to reprice your products and constantly keep you ahead of the competition. From machine learning to advanced exchange algorithms we bring the sharpest tools and the latest technology to the game. We keep you one step ahead of the competition day or night. AND WE LISTEN. Chat or email us with your suggestions and we will work round the clock to win you the sales.</p>
    </div>
</article>
    <!-- /.container -->

</article>
    <!--<div class="col-sm-12 text-center">
        <img class="img-responsive center-block" src="http://placehold.it/140x100" alt="">
        <h3>Vinay Mavani
            <small>Strategist</small>
        </h3>
    </div>-->


   <?php include_once('footer.php'); ?>
