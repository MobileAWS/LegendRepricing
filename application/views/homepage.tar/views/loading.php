<?php include_once('header.php'); ?>
    <?php include_once('nav.php'); ?>
<div class="modal fade" id="confirm-submit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
               redirecting to login page
            </div>
            <div class="modal-body">

                <!-- We display the details entered by the user here
                <table class="table">
                    <tr>
                        <th>Last Name</th>
                        <td id="lname"></td>
                    </tr>
                    <tr>
                        <th>First Name</th>
                        <td id="fname"></td>
                    </tr>
                </table>
-->

            </div>

  <div class="modal-footer">
<!--            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            <a href="#" id="submit" class="btn btn-success success">Submit</a>       -->
        </div>
    </div>
</div>
<?php include_once('footer.php'); ?>