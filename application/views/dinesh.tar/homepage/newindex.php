<article>
	<ul class="bg-evnOdd">
		<li>
			<div class="container">
				<div class="box-welcome">
					<h1>Command the Marketplaces
						<p>Legend pricing is the most popular multi marketplace and buybox winning solution</p>
					</h1>
					<div class="row">
						<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4"> <span class="icon-basket"></span>
							<h2>Lorem Ipsum simply</h2>
							<p>Contrary to popular belief, Lorem Ipsum<br>
								is not simply random text.</p>
						</div>
						<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4"> <span class="icon-home icon-basket"></span>
							<h2>Lorem Ipsum simply</h2>
							<p>Contrary to popular belief, Lorem Ipsum<br>
								is not simply random text.</p>
						</div>
						<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4"> <span class="icon-card icon-basket"></span>
							<h2>Lorem Ipsum simply</h2>
							<p>Contrary to popular belief, Lorem Ipsum<br>
								is not simply random text.</p>
						</div>
					</div>
				</div>
			</div>
		</li>
		<li>
			<div class="container">
				<div class="row">
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"> <img src="<?=base_url();?>/asset/images_d/img-moniter-2.png" alt="" title=""/> </div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<h1>Repricing Features</h1>
						<h6>Rule the marketplaces with automated repricing</h6>
						<p>Automatically repricing the listings bases on lowest selleing price formula</p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
						<a href="#" title="Learn More" class="btn">Learn More<i class="fa fa-angle-double-right"></i> </a> </div>
				</div>
			</div>
		</li>
		<li>
			<div class="container">
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<h1>Repricing worth trying</h1>
						<p>Outsmart the competition and never lose the buy box again. With our Amazon repricing tool, you can set tailored options such as product condition, seller ranking, time of day, and much more.</p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
						<a href="#" title="Learn More" class="btn">Learn More<i class="fa fa-angle-double-right"></i> </a> </div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 alRight"> <img src="<?=base_url();?>/asset/images_d/img-moniter-4.png" alt="" title=""/> </div>
				</div>
			</div>
		</li>
		<li>
			<div class="box-parallax-img">
				<div class="container">
					<div class="row">
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"> <img src="<?=base_url();?>/asset/images_d/img-moniter-1.png" alt="" title=""/> </div>
						<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
							<h1>Repricing worth trying</h1>
							<p>Access millions of shoppers on ebay, Amazon, Rakuten and more by leveraging the inventory you already have. List, update, and revise live listings all from one place.</p>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text </p>
							<a href="#" title="Learn More" class="btn">Learn More<i class="fa fa-angle-double-right"></i></a> </div>
					</div>
				</div>
			</div>
		</li>
		<li>
			<div class="container">
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<h1>Inventory Management</h1>
						<h6>Rule the marketplaces with automated repricing</h6>
						<p>Avoid frustrating stock-outs and overselling. With centralized inventory, you can automatically sync inventory levels across your online store, marketplace (Amazon, eBay), and POS.</p>
						<a href="#" title="Learn More" class="btn">Learn More<i class="fa fa-angle-double-right"></i></a> </div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 alRight"> <img src="<?=base_url();?>/asset/images_d/img-moniter-3.png" alt="" title="" /> </div>
				</div>
			</div>
		</li>
	</ul>
</article>
