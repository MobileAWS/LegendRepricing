<br>
<!--PROVIDED BY MARCELO MARTINS - BOOTLY @ mmartins-->
<div class="container">
    <div class="row">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">
                          <!--<img src="https://cloud.digitalocean.com/assets/cloud-logo-0efc9110ac89b1ea38fc7ee2475a3e87.svg" class="login" height="70">-->
                          <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAHwAlAMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAUBAwYHAv/EAD0QAAEEAQIDBQQJAwIHAQAAAAEAAgMEEQUhBhIxE0FRYXEUIoGxByMyM2JykaHBFVLRc6IkJUJEY4PCFv/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAuEQEAAgECAwgBAwUBAAAAAAAAAQIRAwQFEjETITJBQlGBkWEiobEUccHR8CP/2gAMAwEAAhEDEQA/APcUBAQEBAQEBB8vcGgE95AQfSAgICAgICAgICAgICAgICAgIIl+VrImkOGQ9pxnzCCUCD0KDKAgICAgICAgICAgICAgIINvU6taTsZLEMcuM4keG4/VBHFqvP1uwv8AIStI/YqMpfL44nD3XMPhghBEe6WF2YZHNI7gdv0UoTKGsB7xDbAY/uf3H/CC3QEBAQEBAQEBAQEBAQap38jdup6IKZ2t6VFcdTkuxdu04ewZdyHwcQCG/FQtlaCGJ+7o43A9Dyg5UGXw/TKMn26VZ35oWn+FKGiXRtNIwNPqfCBo/hQYVlvQ6LXhoqQBx3DRgE+g71ZC30qwXsMLz7zBt5hBYICAgICAgICAgICCHqF0VQ1oLO0f05zho8yUFHxJqNyrwzZsxSxm0/lihki3awvcGBw9M5+CiO+RzfGTZuE+FI6+g2oqcsbA+WYsa+WUk93MD1OclWQnfRlxDd1fguld1QtNg2nQNe1ob2rQ7GcDYdT08FCXedyCBq+oN03TL19zC8VK75i0dXcoJx+yhLy/QeI6HEtzT6Ot1qj7GphxjkgDhJBIAXAFxJ7m9RjfCsq6nR79qky1FaLrNrT3ujLz1mZjLST442J8sqB0mjazFqY5TFJBOG5MUg3x4jxRK0QEBAQEBAQEBAQUPEYlDxyR03tkZyk3PuxjPU9yD4i06LUOGGUT7Mxr4tn0zzRtcDkOYdsgOGVXPeKLinRNI1+jBDxVO2vNWGO2rWQxzh4YIJIPhj0VkJfDFKB5pQ6ZWdW0bT24ga7OZD479dznKTKXXSP5WoKXU7ELIpmXGF9SeMxTeQO2f3QcDwl9H+k8N63FrB1SxbZWyakJiB5SQRklv2ticYA3UodE0PdHqFyRjmvsOLgwfaAAw0eu37qBC4PJGpVG/wDMvaR957aQXcuPEIPRx0RLKAgICAgICAgINU8EdiMxzMDmO6goNFetDQhZBCC2MZLR4ZOVWYTDEzK8jgZoo5COhc0HCkHWGMbgYAHd4IIc1zruiFdZmEuQehUitjoVoXl8TSzO5a1xDf0zhEJQpu1Nj6MMphL2EdoASWDx2IRK60HQINHYSJZbE5GDNK4k48AguEBAQEBAQEBAQEBBqsxGWMhpw4bg+aDn57rmOdHJ7r2ncHqEJc5xJb1aVkDtHuxwOY49qHs5g4dyIUkmpcWtGAdPl/Fy4/8ApSJ+iXNVNeR2tGASl/1Yi293zQTzdBwG7knAA3JKJiMux0Gi6pV55wBPJu4f2juCglZ5Higyg0y2q8IzLYiYPxPARaKWt0hAm4j0aA4k1SrnwbIHH9lbkt7Oiuy3NulJ+kGbjXQ4ulp7/wAkTj/CtGlZtXhe6n04+VppGr0tXgdNSmDw04c0jDm+oVbVmvVza+31Nvbl1IwnqrAQEBAQYJwg+JZo4m80r2MHi52EwmKzPSHP67b0C1Hi1qtWCZo92RszeYfDvCtFLT0h0U2m4t4aTPw871W9JVnxVuQ3G52khyMeuR8sq8aVp8nTXhW5t6cf3Qjrl3lx2f6YU9jZrHBNz5zH3P8ApFdqt+SQBsYZk/aecqexlpTgl/VZZ6Xrl/TX9tFWpy2O6Wbmdyeg2A9VPZQ6a8J0fVaU6XjXiWTYWq0X+nCP5yr9nR0V4Zsq9YmflDdxDr8n3urWTnuaQ35AKeSns2jZ7SvTThFlu3J/v7diTPc6UlTiG1dPSr4axHwjOcxr2tcWhzugJ3KZX56xOH1hETLKDrvo0eW61Yjzs+uTjxw4f5Kz1ujyuM1zoVn8vTFzPmlLxLxBBoVaN8kbpZZSRHGDjOOpJ8FelJs7Nns77q0xE4iOsuTl+kS4RiHToG+b5HO+WFr2Me71q8E0/VeUGbjvW5M8prRD8EX+SVMaVW9eEbWOuZ+UGbivXZj72oytHgxrW/IK3Z19m9eHbSvo/lCm1TUJ89rftPz/AHTO/wAqeWvs1jb6NPDWPqEJzQ53M8czvE7lS1i0x0A0eiZk5pZLMAEtOD0z3pki3lljlb4bpmTmkOGjJIHqUyibY6tFi9TrAGezDGCMgueBkKMxDK+tp08VogN+oP8AuI/vGx7HPvO6D4pzQdvp+/nj7RJtcqRhpjbNMSHkNjjJOGnDuvgVXnhjbe6UdMz18vbq0WOIWsz7PTmnHYMnywge6446dVHafhnffxHhrM90T8Sh39QfY1SrI2vyRVLwgdIXbkuGOnhuFE2zMMNXXtfWrbHdW2Pt0y1esIQ6b6PX8nErG/3wvb8j/CpreFwcXrnazPtMPVVyvlXCfShDmvQsAfZe6M/EZ/grfRnvmHucEv8AqvT5cAtnusIOstaK+5o2hR0oqMctgESPJAe9+CRlw3IxnI7jhZRbEy8qm6jT1tabzM4+sIcfC0z5o2m9W7OSKWQSxBzx9WQHDu33/ZT2n4azxCsRM8s5iYj269GxnD9BkVmxLqbpq8MMMvNXjGSHkjcE7YwnPPTCs7zVma1imJmZjv8AwsG8PaTUsyRWo7M4GoMqh3bcga18bXhxwN+uFXmtPRh/Wa96xakxH6Zt09pmMK7i88vBHZVYWsnpzzVWygkuY5uXZHrt+qRnMmnz9re0W8Veb9v8PKX25vZnOlt2pmTafHYIE2CHNcOYAgbdVWZ7urOdW/JObTMTWJ6+cT3vkdjPFbY+aMsr24pY+Ue0R+83GCCd2+Ke8K/otW0TPdExMeqO+P4bIY+etC6vUmiex0sAdDEZI3NPvbtdvykn4KcfhetYmkTWsxjMd0Zj6nylvn0q5adRe2DsBNE02GsHKIpIweQ4z5/spmszhpfbal+ScYzHf+JjOG+vpmox1NOlayI2Yu27Zkj+UESEk7jKmKziGlNvrRSloiOaObOfylaRpE9KapNLLGXRVDBIG5397IPwU1pMS1221tpWraZ6Rj98wWdCdPYsSNuGOKeVkxjEQOHN88+STTMyX2c2taYtiJmJxj2XK0d58EWwvOCpOz4pofic9v8AscqavhlxcSjO0v8AH8w9fXK+Rcv9IsPacOOkxnspmO/U8v8AK10vE9PhFsbmI94n/byxdD6YQdBp2sV6unaW13MZ6V8y8ob1iLd9/HJ6LOa98uDV2t76mpMdLVx8pn/6LT6ctT2OK1NHDPPI7tQ1uWyg5aN/Ej9FHJPmx/otbUi3PMRMxWPrzVnDdqvDLdrWX1mVbMBa5tjm5XYOwy3ceqvaJ7ph07vSvaKXpE80T5dVnrXE/Z3nHTXVJ45I4nSGSIua2VoxlvNjy3VK6fd3ubbcP5tP/wBYmJ7/AD8p91DNrV6aC5A+x9VceXzsDRhzjgE9Nug6K/JHs7o2enHLPL3xGIc9o2kVtNpiJ0cEkvKWvlEYBeM9D49yilOWFNts66NIiYjPvhYtEbfshrfQYV8OqKY6Q+i7Od0wtES+q8M1mURV4nyyEEhjG5OAMlTMxHUvelI5rziGtxDa1ey58XY2Obsy2VpOxxuO7ocZ64KiLRM4hSmtp31LaUdYboq1ib7mvNJ+SMu+SnMLW1NOvimIT4dA1ibHZ6Xbwf7oi354VeevuxtvdtXreE6HgzXZetVkf+pK0fLKr2tHNbim1r6s/CdD9H+pux21mrGPIud/AUdtVjbjOjHSsy6Hhrg2LSLYuWLPtE7AQzDOVrc7E9TvhZ31eaMPO3nE7binJWuIdWsnlqniuD2jhzUI8ZPYlwHm3cfJWpOLQ6tlfk3FJ/LxorsfZcsCGIYJx1ICYTywzEHSnELTIfwDPySYx1RaIr17kuLR9UnP1WnW3f8ApcFHNWPNlbdaFPFePt8y6RdifqFe/VdDKKLpIe12w8nDSDztGevj6FZX1I9MvN3vE6V5ewv5963i4Ov6tcmtaXLpzNPc7lDRJ9kgAEANLx/u7+5RXWxHew2vF4pp8urmZ/78qniPSLOh6g2g58U074g9mMjmySMDvO4U9vHs0txyvpp9y7Nv0dQeyGT22y6cxktjw1rebGwOxOMqO3n2YW45q+mkfu5zgHSIdW1e3S1ZjZH1Y/r4Q90boX52BAOe4qvbXYW4xup6TEfEf5y7q7wbR7KL+lMipTNkaXSmISlzM+83384yMjPmqTe090y5NXe7jWry3tmPY4c4Zl0mxI+R9cwufI8RDneQ5xyTkkNG+TswdcDAGFVz805zl0wAA2ACIZQEBAQEGHAOGCMgoOak4H0N9h0nYytBOezZIQ0engtO1s9KOLbqK8uf2SIeDtAi3/p7Hn/yOc75lR2lvdnbiW6n1/XcnwaNpdf7nT6rPSJqrzTLntuda3ivP2mtjYwYY0NHgBhQxmZnqzgINVirXssDLMMcrQ7mDZGhwB8d+9BW6xqLNFrBlOi6xO/7utAA3PiT4DzQeZf1K9Nxs3Xr2nxw36zAxsMnN7sW4w05wdyd8ZyegQeoSa5Ui0B2tPJ9mbEZCB1/L652QeacL6nZrcSXdZqaeZ7Wtyn/AIZjsucGb7Zw0BoIy44G47zhB6xTsSTRg2K7q8uN43ODsehGxQSEBAQEBAQEBAQEBAQEGt7nNGzclBFFmJjHyTlsch65ONvVQPO+LZRbuQyaZDLanZKW4gYX+44YcCegHQ7n/pUwhBbpPF1jh7+kGER1XdQ8+9gv5/mpHXcHaeyjfvTTV3wGOOKrXMgxmNrQ9xHq97s/lHgqylc6rqUFeeuY5Q6QPxyN3JB67ILWGTtGg8rgPMYUjYgICAgICAgICAgICAgwWtPVoPwQYDGjo0fog+kGMDwCDDWMactY0E94CD6QEBAQEBAQf//Z" class="login" height="70">
                          <h3 class="text-center">Forgot Password?</h3>
                          <p>If you have forgotten your password - reset it here.</p>
                            <div class="panel-body">
                              
                              <form class="form" id="forgot_password" action="#" method="post"><!--start form--><!--add form action as needed-->
                                <fieldset>
                                  <div class="form-group">
                                    <div class="input-group">
                                      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                                      <!--EMAIL ADDRESS-->
                                      <input name="email" id="emailInput" placeholder="email address" class="form-control" type="email"
 required>
<!-- oninvalid="setCustomValidity('Please enter a valid email address!')" onchange="try{setCustomValidity('')}catch(e){}"-->
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <input class="btn btn-lg btn-primary btn-block" value="Send My Password" type="button" id="send_forgot">
                                  </div>
                                </fieldset>
                              </form><!--/end form-->
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
