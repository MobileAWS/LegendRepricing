<footer>
	<div class="container">
		<div class="btn-backTotop"> <a href="#home" title="Back To Top"><i class="fa fa-chevron-up"></i>top</a> </div>
		<div class="row box-footer">
			<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5 box-aboutUs">
				<h6>legend repricing</h6>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			</div>
			<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
				<h5>Lorem</h5>
				<ul class="list-footermenu">
					<li><a href="#" title="About Us">About us</a></li>
					<li><a href="#" title="Ebay">Ebay</a></li>
					<li><a href="#" title="Web analytics">Web Analytics</a></li>
					<li><a href="#" title="Blog">Blog</a></li>
					<li><a href="#" title="Amazon">Amazon</a></li>
					<li><a href="#" title="Rakuten">Rakuten</a></li>
					<li><a href="#" title="Magento">Magento</a></li>
					<li><a href="#" title="Product Help">Product Help</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="footer-copyright">
		<div class="container">
			<p>copyright &copy; Legend Repricing 2015</p>
		</div>
	</div>
	</div>
</footer>
<script type="text/javascript" language="javascript" src="<?=base_url();?>/asset/js_d/jquery.flexslider-min.js"></script> 
<script type="text/javascript" language="javascript" src="<?=base_url();?>/asset/js_d/bootstrap/bootstrap.min.js"></script> 
<script type="text/javascript" language="javascript" src="<?=base_url();?>/asset/js_d/html5.js"></script> 
<script type="text/javascript" language="javascript" src="<?=base_url();?>/asset/js_d/custom.js"></script>
</body>
</html>
