<?php

error_reporting(E_ALL); ?>
<html>
<head>
<base href="http://localhost/githubs/URLResolver.php/tools/">
<title>RainyDayMarketing --> Jasmine Lee</title>


<link rel="icon" href="files/5a0ac02c7a0ce1daf36d95c34c0a02697f8cc74b0a1ee6e0">



<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.10.4.custom.css">
<link rel="stylesheet" type="text/css" href="js/tablesorter/themes/blue/style.css"/>
<link rel="stylesheet" href="css/fa/font-awesome.min.css">
<!-- <link rel="stylesheet" type="text/css" href="/css/slimmenu.css"> -->

<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui-1.10.4.custom.js"></script>
<script src="js/tinymce/tinymce.min.js"></script>
<script src="js/jquery.slimmenu.js"></script>
<script src="js/tablesorter/jquery.tablesorter.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>-->

<style>
li {
 word-wrap: break-word;
}

</style>
<script>
$( document ).ready(function() {
  //var currentDate = new Date();



  var from = ""
    var to = ""

    $(document).on("click", "#surf" , function(e) {
      e.stopPropagation();
      e.preventDefault();
    $(this).attr("disabled","disabled");
      var datastring = $("#form_settings").serialize();
        {                   
          $('input[type=submit]').attr('disabled', 'disabled');
          $.ajax({
            url: "process.php",
              type: "POST",
              data: datastring,
              cache :false,
              success : function(response) {
                var obj= JSON.parse(response);
                $("#offer_redirects").html(obj.offer_redirects);
                $("#screenshot").html(obj.screenshot);
                $("#final_page").html(obj.final_page);
                //                alert('Thank You ..Your listings table will be populated shortly');
              },
                complete: function() {
               $(this).removeAttr("disabled");
                }
          });
      }
});  

$( "#from" ).datepicker({
  changeMonth: true,
    changeYear: true,
    numberOfMonths: 1,
    dateFormat: "yy-mm-dd",
    onClose: function( selectedDate ) {
      $( "#to" ).datepicker( "option", "minDate", selectedDate );
    }
});

  $( "#to" ).datepicker({
    changeMonth: true,
      changeYear: true,
      numberOfMonths: 1,
      dateFormat: "yy-mm-dd",
      onClose: function( selectedDate ) {
        $( "#from" ).datepicker( "option", "maxDate", selectedDate );
      }
  });

  $("#from").datepicker("setDate", from);
  $("#to").datepicker("setDate", to);

});
</script>

<script>
//when two datepickers are needed on same screen
$( document ).ready(function() {
  //var currentDate = new Date();


  var from2 = ""
    var to2 = ""


    $( "#from2" ).datepicker({
      changeMonth: true,
        changeYear: true,
        numberOfMonths: 1,
        dateFormat: "yy-mm-dd",
        onClose: function( selectedDate ) {
          $( "#to2" ).datepicker( "option", "minDate", selectedDate );
        }
    });

  $( "#to2" ).datepicker({
    changeMonth: true,
      changeYear: true,
      numberOfMonths: 1,
      dateFormat: "yy-mm-dd",
      onClose: function( selectedDate ) {
        $( "#from2" ).datepicker( "option", "maxDate", selectedDate );
      }
  });

  $("#from2").datepicker("setDate", from2);
  $("#to2").datepicker("setDate", to2);

});
</script>
<script>
function dateSelect(dates) {
  var check = dates.indexOf(" ");
  if(check > 0) {
    var my_dates = dates.split(" ");
    var start_date = my_dates[0];
    var end_date = my_dates[1];
    document.getElementById("from").value = start_date;
    document.getElementById("to").value = end_date;
  }
  else {
    document.getElementById("from").value = dates;
    document.getElementById("to").value = dates;
  }
}
</script>
<script>
function dateSelect2(dates) {
  var check = dates.indexOf(" ");
  if(check > 0) {
    var my_dates = dates.split(" ");
    var start_date = my_dates[0];
    var end_date = my_dates[1];
    document.getElementById("from2").value = start_date;
    document.getElementById("to2").value = end_date;
  }
  else {
    document.getElementById("from2").value = dates;
    document.getElementById("to2").value = dates;
  }
}
</script>

<script>
$( document ).ready(function() {
  //for invoicing - invoice date and due date


  var idate = ""
    var ddate = ""











    $( "#idate" ).datepicker({
      changeMonth: true,
        changeYear: true,
        numberOfMonths: 1,
        dateFormat: "yy-mm-dd",
/*onClose: function( selectedDate ) {
  $( "#ddate" ).datepicker( "option", "minDate", selectedDate );
}*/
    });

  $( "#ddate" ).datepicker({
    changeMonth: true,
      changeYear: true,
      numberOfMonths: 1,
      dateFormat: "yy-mm-dd",
/*onClose: function( selectedDate ) {
  $( "#idate" ).datepicker( "option", "maxDate", selectedDate );
}*/
  });

  $("#idate").datepicker("setDate", idate);
  $("#ddate").datepicker("setDate", ddate);

});
</script>


<!-- editor -->

<script>
tinymce.init({
  selector:'textarea#editor',
    width: 900,
    height: 500,
    relative_urls: false,
    convert_urls: false,

    plugins: [
      "advlist autolink link image lists charmap print preview hr anchor pagebreak",
      "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
      "save table contextmenu directionality template paste textcolor"
    ],
    /*toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media fullpage | forecolor backcolor emoticons", */
    toolbar1: "newdocument fullpage | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
    toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | inserttime preview | forecolor backcolor",
    toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
});
</script>

<script>
function setVisibility(id) {
  if(document.getElementById('hide_btn').value ==  'Close'){
    document.getElementById('hide_btn').value = 'Show More ';
    document.getElementById(id).style.display = 'none';
  }else{
    document.getElementById('hide_btn').value = 'Close';
    document.getElementById(id).style.display = 'inline';
  }
}
</script>



<script>
function checkAll() {
  var checkboxes = document.getElementsByTagName('input'), val = null;    
  for (var i = 0; i < checkboxes.length; i++)
  {
    if (checkboxes[i].type == 'checkbox')
    {
      if (val === null) val = checkboxes[i].checked;
      checkboxes[i].checked = val;
    }
  }
}
</script>

<script>
$(document).ready(function(){
  $("a.dropdown-link").click(function(e) {
    e.preventDefault();
    var $div = $(this).next('.dropdown-container');
    $(".dropdown-container").not($div).hide();
    if ($div.is(":visible")) {
      $div.hide() 
    }  else {
      $div.show();
    }
  });

  $(document).click(function(e){
    var p = $(e.target).closest('.dropdown-processed').length
      if (!p) {
        $(".dropdown-container").hide();
      }
  });
});
</script>

<script>
$(document).ready(function(){
  $('#currently_active').click(function() {
    $('#search_div').fadeToggle("fast","linear");
    $('#lastseen').fadeToggle("fast","linear");
    $('#world_clock').fadeToggle("fast","linear");
  });
});
</script>

<script>
$(document).ready(function(){
  $('#world_clock').click(function() {
    $('#search_div').fadeToggle("fast","linear");
    $('#world_clocks').fadeToggle("fast","linear");
    $('#currently_active').fadeToggle("fast","linear");
  });
});
</script>

<script>
$( document ).ready(function() {
  $('#navigation').slimmenu(
      {
        resizeWidth: '200', /* Navigation menu will be collapsed when document width is below this size or equal to it. */
          collapserTitle: 'Menu', /* Collapsed menu title. */
          animSpeed: 'medium', /* Speed of the submenu expand and collapse animation. */
          easingEffect: null, /* Easing effect that will be used when expanding and collapsing menu and submenus. */
          indentChildren: false, /* Indentation option for the responsive collapsed submenus. If set to true, all submenus will be indented with the value of the option below. */
          childrenIndenter: '&nbsp;' /* Responsive submenus will be indented with this character according to their level. */
      });
});
</script>

<script>
$( document ).ready(function() {
  $('#navigation2').slimmenu(
      {
        resizeWidth: '200', /* Navigation menu will be collapsed when document width is below this size or equal to it. */
          collapserTitle: 'Menu', /* Collapsed menu title. */
          animSpeed: 'medium', /* Speed of the submenu expand and collapse animation. */
          easingEffect: null, /* Easing effect that will be used when expanding and collapsing menu and submenus. */
          indentChildren: false, /* Indentation option for the responsive collapsed submenus. If set to true, all submenus will be indented with the value of the option below. */
          childrenIndenter: '&nbsp;' /* Responsive submenus will be indented with this character according to their level. */
      });
});
</script>

<script>
$(document).ready(function(){
  $("#search_input").autocomplete({
    source: '/admin/form_complete',
      select: function(event, ui){
        $('#search_input2').val(ui.item.id);
        $('#search_input3').val(ui.item.type);
      },
        minLength:3
  });
});
</script>

<script>
function showHide(divId){
  $(".view_contents").hide();
  $("#" + divId).show();
}
</script>






<script>
$(document).ready(function() {
  $("<input type='hidden' value='' />")
    .attr("name", "csrf_token")
    .attr("value","8ca9e1e7bee9bc81f134176a7948f1b6948f999e54bcc51bcdcec00cd300f720")
    .prependTo("form");
});
</script>




<style>



html,body{

  margin:0;

  padding:0;

  font:12px;

  font-family: 'Open Sans', sans-serif;

  width:100%;

  height:100%;

  background:#FFFFFF;



  background-image: url(../);



}



.admin_notice {

  border: 2px solid #F00000;

  background-color: #FFFFFF;

  color: black;

  -webkit-border-top-right-radius: 8px;

  -webkit-border-top-left-radius: 8px;

  -moz-border-top-right-radius: 8px;

  -moz-border-top-left-radius: 8px;

  border-top-right-radius: 8px;

  border-top-left-radius: 8px;

  -webkit-border-bottom-right-radius: 8px;

  -webkit-border-bottom-left-radius: 8px;

  -moz-border-bottom-right-radius: 8px;

  -moz-border-bottom-left-radius: 8px;

  border-bottom-right-radius: 8px;

  border-bottom-left-radius: 8px;

}



input#from {

  width: 95px;

}



input#to {

  width: 95px;

}



input#from2 {

  width: 95px;

}



input#to2 {

  width: 95px;

}





#container{

  margin:0px;

  padding:5px;

  width:100%;

  height:100%;

}



tr{

  margin:0px;

  padding:0px;

}



td{

  margin:0px;

  padding:0px;

}



form{

  margin:0px;

}



.hr_class{

  margin: 8px 0px 8px 0px;

  border: 0;

  height: 1px;

  background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));

}



#header{

  align:center;

  width:1200px;

  margin:0px;

  padding:0px;

  font-size:12px;

  min-height:500px;

}



#head_left{

  text-align:left;

  float:left;

  width:400px;

  height:125px;

  position:relative;

}



#head_left_1{

  padding-left:10px;

  -webkit-appearance: none;

}



#head_left_1 a {

  color: 000000;

}



#head_left_1 a:visited {

  color: 000000;

}



#head_left_1 a:link {

  color: 000000;

}



#head_left_1 a:hover {

  color: 000000;

}



#head_left_1 a:active {

  color: 000000;

}



#head_middle{

  text-align:center;

  float:left;

  width:400px;

  height:125px;

}



#head_right{

  position:relative;

  float:right;

  width:395px;

  height:125px;

  text-align:right;

  line-height:1.75em;

  padding-right:5px;

  margin-right:0px;

}



#head_right span{

  padding-left:15px;

}



/* Global Search Box */



#search_div{

  position:absolute;

  margin:0px 0px 0px 0px;

  right:8px;

  bottom:10px;





}



#search_div input{

  font-size:14px;

  color: #333333;

  border: 1px solid silver;

  border-style: solid;

  box-shadow: inset 0px 0px 0px rgba(0, 0, 0, 0.17);

  background-color: #FFFFFF; /* Menu Tab Background Color */

  width:200px;

  padding: 10px 5px 10px 12px;

  /*  -webkit-border-top-right-radius: 5px;

  -webkit-border-top-left-radius: 5px;

  -moz-border-top-right-radius: 5px;

  -moz-border-top-left-radius: 5px;

  border-top-right-radius: 5px;

  border-top-left-radius: 5px;

  -webkit-border-bottom-right-radius: 5px;

  -webkit-border-bottom-left-radius: 5px;

  -moz-border-bottom-right-radius: 5px;

  -moz-border-bottom-left-radius: 5px;

  border-bottom-right-radius: 5px;

  border-bottom-left-radius: 5px; */

}



.search_input::-webkit-input-placeholder {

  color: #333333;

}

.search_input:-moz-placeholder { /* Firefox 18- */

  color: #333333;

}

.search_input::-moz-placeholder {  /* Firefox 19+ */

  color: #333333;

}

.search_input:-ms-input-placeholder {

  color: #333333;

}



.search_input:focus { 

  outline: none;

  border-color: #171716;

}



/* End Global Search */



/* Start Classic Navigation */



#classic_menu{

  text-align: center;

  width: auto;

  margin: auto;

  height:32px;

  padding:0px 0px 0px 8px;

}



#classic_menu select{

  margin:0px;

  float:left;

  width:148px;

  height:30px;

  font-size:14px;

  /* background:transparent; */

  /* -webkit-appearance: none; */

}



#classic_menu select:hover { 

  outline: none;

  border-color: #171716;

  box-shadow: 0px 0px 1px #171716;

}





/* #classic_menu span{

color:#fff;

font-size:20px;

}



#classic_menu td{

  padding:10px 0px 10px 7px;

  }



  #classic_menu select{

    width:128px;

    font-size:14px;

    }



    #nav_menu {

      float: left;

      margin: 5px 0px 0px 0px;

      padding: 0px;

      }



      #nav_menu ul {

        margin:0px;

        padding:0px;

        list-style: none;

        z-index:9999;

        }



        #nav_menu ul li {

          float: left;

          background-color: #1C1C1C; 

          -webkit-border-radius: 4px 4px 4px 4px;

          -moz-border-radius: 4px 4px 4px 4px;

          border-radius: 4px 4px 4px 4px;

          }



          #nav_menu ul li a {

            width:118px;

            margin:0px;

            padding:0px;

            float: left;

            color: #FFFFFF;

            text-decoration: none;

            padding: 10px 16px;

            background-color: #1C1C1C;

            border-left: 1px solid #0A2C4F;

            border-right: 1px solid #0A2C4F;

            -webkit-border-radius: 4px 4px 4px 4px;

            -moz-border-radius: 4px 4px 4px 4px;

            border-radius: 4px 4px 4px 4px;

            }



            #nav_menu ul li a :last-child{

              width:118px;

              margin:0px;

              padding:0px;

              float: left;

              color: #FFFFFF;

              text-decoration: none;

              padding: 10px 16px;

              background-color: #1C1C1C;

              border-left: 1px solid #0A2C4F;

              border-right: 1px solid #0A2C4F;

            }



            #nav_menu li ul {

              background: #0B5188;

              left: -999em;

              margin: 31px 0px 0px;

              position: absolute;

              width: 150px;

              border-top: 1px solid #0A2C4F;

              border-bottom: 0px solid #0A2C4F;

              border-left: 1px solid #0A2C4F;

              border-right: 1px solid #0A2C4F;  

            }



            #nav_menu li ul a {

              background: none;

              border:0px none;

              margin-right:0px;

              width: 118px;

              border-bottom: 1px solid #0A2C4F;

            }



            #nav_menu ul li a:hover{

              color: #FFFFFF;

              background: #171716;

            }



            #nav_menu li ul a:hover{

              color: #FFFFFF;

              background: #171716;

            }



            #nav_menu li:hover ul {

              left:auto;

            }



            #nav_menu li li ul {

              margin: -1px 0 0 150px;

              visibility: hidden;

            }



            #nav_menu li li:hover ul {

              visibility: visible;

            } */



/* End Classic Navigation */









            /* Start New Navigation */



#navigation{

  position:absolute;

  margin:0px 0px 0px 6px;

  bottom:0px;

}



#navigate {

  /* These entries relate to the Menu Tab itself, not the children.  */

  width:167px;

  color:#B5D133;

  border-bottom:1px;

  border-right:0px;

  margin-top:5px; /* We use negative here to drop the menu so it fits the UI as a tab. */

  margin-bottom:0px; /* We use negative here to drop the menu so it fits the UI as a tab. */

  margin-left:5px;

  padding: 10px 5px 10px 12px;  /* Size of the Menu Tab is controlled by padding - T/R/B/L */

  font-size:15px;

  -webkit-border-top-right-radius: 7px;

  -webkit-border-top-left-radius: 7px;

  -moz-border-top-right-radius: 7px;

  -moz-border-top-left-radius: 7px;

  border-top-right-radius: 7px;

  border-top-left-radius: 7px;

}





/* Style the Notification Icons based on user preference for active/inactive status.*/



.admin-notice-ticket {

  color: #888888;



  color: #F00000;





}



.admin-notice-message {

  color: #888888;





}



.notice_inactive {

  color: #888888;

}



.admin-notice-aff-change {

  color: #888888;





}



.admin-notice-aff-pend {

  color: #F00000;



}

.admin-notice-aff-list {

  color: #888888;

}



.admin-notice-select-req {

  color: #888888;



  color: #F00000;



}







/* Don't change menu-collapser settings - the collapser is the toggle arrow, and is not displayed. */

.menu-collapser {

  position: relative;

  background-color: #111;

  color: #FFF;

  text-shadow: 0px 1px 0px rgba(0,0,0,0.5);

  width: 100%;

  height: 48px;

  line-height: 48px;

  font-size: 16px;

  padding: 0px 8px;

  box-sizing: border-box;

  -moz-box-sizing: border-box;

  -webkit-box-sizing: border-box

}



.collapse-button {

  position: absolute;

  right: 8px;

  top: 50%;

  width: 4px;

  background-color: #0E0E0E;

  background-image: linear-gradient(to bottom, #151515, #040404);

  background-repeat: repeat-x;

  border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);

  border-radius: 4px 4px 4px 4px;

  border-style: solid;

  border-width: 1px;

  color: #FFFFFF;

  box-shadow: 0px 1px 0px rgba(255, 255, 255, 0.1) inset, 0 1px 0 rgba(255, 255, 255, 0.075);

  padding: 7px 10px;

  text-shadow: 0px -1px 0px rgba(0, 0, 0, 0.25);

  cursor: pointer;

  font-size: 14px;

  text-align: center;



  transform: translate(0, -50%);

  -o-transform: translate(0, -50%);

  -ms-transform: translate(0, -50%);

  -moz-transform: translate(0, -50%);

  -webkit-transform: translate(0, -50%);



  box-sizing: border-box;

  -moz-box-sizing: border-box;

  -webkit-box-sizing: border-box

}



.collapse-button:hover, .collapse-button:focus {

  background-image: none;

  background-color: #040404;

  color: #FFF;

}



.collapse-button .icon-bar {

  background-color: #F5F5F5;

  border-radius: 1px 1px 1px 1px;

  box-shadow: 0px 1px 0px rgba(0, 0, 0, 0.25);

  display: block;

  height: 2px;

  width: 1px;

  margin: 2px 0px;

}



ul.slimmenu {

  list-style-type: none;

  margin: 0px;

  padding: 0px;

  width: 100%;

}



ul.slimmenu li {

  position: relative;

  display: inline-block;

  width:183px;

  background-color: #1F1F1F; /* Menu Tab Background Color */

  border-top: 1px solid #D1D1D1; /* separators between items and right border */

  border-right: 1px solid #D1D1D1;

}



ul.slimmenu > li {

  margin-right:-5px;

  border-left: 1px solid #D1D1D1;

  width:159px;

}



ul.slimmenu > li:first-child {

  border-left: 0px;

}



ul.slimmenu > li:last-child {

  margin-right: 0px;

}



ul.slimmenu li a {

  display: block;

  color: #B5D133; /* Text color: menu children #1C1C1C*/

  padding: 10px 5px 10px 12px;

  /* font-size: 16px; */

  font-weight: 400;

  text-decoration:none;

  text-shadow: 0 1px 0 rgba(255,255,255,0.2);

  transition: background-color 0.5s ease-out;

  -o-transition: background-color 0.5s ease-out;

  -moz-transition: background-color 0.5s ease-out;

  -webkit-transition: background-color 0.5s ease-out;

}



ul.slimmenu li a:hover {

  background-color: #4A4949; /* On-Hover Menu Children BG Color #1C1C1C*/

  text-decoration: none;

}



ul.slimmenu li .sub-collapser {

  /* background: none repeat scroll 0 0 rgba(0, 0, 0, 0.075); */

  position: absolute;

  right: 0px;

  top: 0px;

  width: 8px;

  height: 100%;

  text-align: center;

  z-index: 999;

  cursor: pointer;

}



ul.slimmenu li .sub-collapser:before {

  content: '';

  display: inline-block;

  height: 100%;

  vertical-align: middle;

  margin-right: -0.25em;

}



ul.slimmenu li .sub-collapser > i {

  color: #333;

  font-size: 18px;

  display: inline-block;

  vertical-align: middle;

}



ul.slimmenu li ul {

  margin: 0px;

  list-style-type: none;

}



ul.slimmenu li ul li {

  background-color: #171716

}



ul.slimmenu li > ul {

  display: none;

  position: absolute;

  left: -40px;

  top: 100%;

  z-index: 999;

  width: 100%;

}

ul.slimmenu li > ul > li ul {

  display: none;

  position: absolute;

  left: 144px;

  top: 0px;

  z-index: 999;

  width: 100%;

}



ul.slimmenu.collapsed li {

  display: block;

  width: 100%;



  box-sizing: border-box;

  -moz-box-sizing: border-box;

  -webkit-box-sizing: border-box

}



ul.slimmenu.collapsed li a {

  display: block;

  border-bottom: 1px solid rgba(0, 0, 0, 0.075);



  box-sizing: border-box;

  -moz-box-sizing: border-box;

  -webkit-box-sizing: border-box

}



ul.slimmenu.collapsed li .sub-collapser {

  height: 40px;

}



ul.slimmenu.collapsed li > ul {

  display: none;

  position: static;

}



/* End New Navigation */



.colorselect {

  width:181px;

}



#home_button{

  background:#cacaca;

  -webkit-border-radius:5px;

  -moz-border-radius:5px;

  padding:10px;

  color:#000000;

  text-align:center;

}



#world_clocks {

  display: none;

}



#lastseen {

  display: none;

}



tr.space_under > td

{

  padding-bottom: 1em;

}



#page_content{

  background-repeat: repeat;

  width:1200px;

  display:block;

  margin:0px 0px 10px 0px;

  padding:0px 0px 0px 0px;

  font-size:11px;

  /* position:absolute; */



  background-image: url(../);

  background-repeat: repeat;

  border:1px #aaa solid;

  -moz-box-shadow: 0px 0px 0px 0px rgba(68,68,68,0.6);

  -webkit-box-shadow: 0px 0px 0px 0px rgba(68,68,68,0.6);

  box-shadow: 0px 0px 0px 0px rgba(68,68,68,0.6);

  /*          -webkit-border-radius: 7px;

  -moz-border-radius: 7px;

  border-radius: 7px; */



}



.image_logo{

  margin-top:5px;

  border:0px;

  max-width:400px;

  max-height:120px;

}



.page_top{

  background-color: #1C1C1C;

  color:#CCCCCC;

  position:relative;

  /* width: 100%; */

  font-size: 18px;

  padding:8px 8px;

  margin: 3px 3px 25px 3px;

  text-align:left;

  border:1px #043554 solid;



  -moz-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  -webkit-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);



  /*  -webkit-border-top-right-radius: 7px;

  -webkit-border-top-left-radius: 7px;

  -moz-border-top-right-radius: 7px;

  -moz-border-top-left-radius: 7px;

  border-top-right-radius: 7px;

  border-top-left-radius: 7px; */

}



.page_top a{

  color:#CCCCCC;

  text-decoration:none;

}



.page_top a :visited{

  color:#CCCCCC;

  text-decoration:none;

}



.page_top a:link{

  color:#CCCCCC;

  text-decoration:none;

}



.page_top a :hover{

  color:#CCCCCC;

  text-decoration:none;

}



.page_top a :active{

  color:#CCCCCC;

  text-decoration:none;

}



.page_bottom{



  background-color: #1C1C1C;

  color:#CCCCCC;

  margin-left: auto;

  margin-right: auto;

  text-align: center;

  position: relative;

  font-weight; bold;

  border:1px #043554 solid;

  -moz-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  -webkit-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);



  /*  -webkit-border-bottom-right-radius: 7px;

  -webkit-border-bottom-left-radius: 7px;

  -moz-border-bottom-right-radius: 7px;

  -moz-border-bottom-left-radius: 7px;

  border-bottom-right-radius: 7px;

  border-bottom-left-radius: 7px; */

  padding:8px 8px;



}



.page_bottom a{

  color:#CCCCCC;

  text-decoration:none;

}



.page_bottom a :visited{

  color:#CCCCCC;

  text-decoration:none;

}



.page_bottom a:link{

  color:#CCCCCC;

  text-decoration:none;

}



.page_bottom a :hover{

  color:#CCCCCC;

  text-decoration:none;

}



.page_bottom a :active{

  color:#CCCCCC;

  text-decoration:none;

}



.page_middle{

  background-color: #1C1C1C;

  color:#CCCCCC;

  font-weight: bold;

  border:1px #043554 solid;

  -moz-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  -webkit-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  padding: 5 5 5 10px;

}



.page_middle a{

  color: white;

}



.page_top_2{

  background-color: #1C1C1C;

  color:#CCCCCC;

  border:1px #043554 solid;

  -webkit-border-radius:8px;

  -moz-border-radius:8px;

  padding:10px;

}



.page_top_2 a{

  color:#CCCCCC;

}



.page_middle_2{

  background-color: #1C1C1C;

  color:#CCCCCC;

  border:1px #043554 solid;

  -moz-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  -webkit-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);   

  padding:5 5 5 5px;

}



.page_middle_2 a{

  color: #CCCCCC;

}



.page_middle_e{

  background-color: #FF0000;

  color: #FFFFFF;

  border:1px #043554 solid;

  -moz-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  -webkit-box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);

  box-shadow: 1px 1px 1px 1px rgba(68,68,68,0.6);   

  padding:5 5 5 5px;

}



#footer{

  width:1024px;

  margin:0px auto;

  background:#ccc;

  padding:0px;

  color:#fff;

}



tr.even td{

  background: #DDDDDD;

  color: #000000;

}



tr.odd td{

  background: #FFFFFF;

  color: #000000;

}



div.even div{

  background: #DDDDDD;

  color: #000000;

}



div.odd div{

  background: #FFFFFF;

  color: #000000;

}



tr.row_highlight {

  background-color:#DDDDDD;

  margin:0;

  border:0;

  padding:0;

} 



#notices{

  background: none repeat scroll 0 0 #c00;

  border: 0px solid #710000;

  color: #fff;

  padding-top: 10px;

  width: 350px;

  border-radius: 10px;

  margin:0px;

}



#notices a:link {

  text-decoration: none;

  text-transform: none;

  color: #fff;



}



#notices a:visited {

  text-decoration: none;

  text-transform: none;

  color: #fff;



}



#notices a:hover {

  text-decoration: none;

  text-transform: none;

  color: #fff;

}



#notices a:active {

  text-decoration: none;

  text-transform: none;

  color: #fff;

}



#notices span{

  color:#000;

  background:#fff;

  padding:3px;

  margin:0px;

}



.aff_table{

  font-size:14px;

  margin:0px 0px;

  border:1px #999 solid;

}



.aff_table td{

  padding:0px;

}



.indent10px {

  margin-left: 10px;

}





#aff_reg_add {

  display: none;

}



#merchant_radio{

  display: none;

}



.link_button {

  -moz-box-shadow:inset 0px 1px 0px 0px #ffffff;

  -webkit-box-shadow:inset 0px 1px 0px 0px #ffffff;

  box-shadow:inset 0px 1px 0px 0px #ffffff;

  background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #ededed), color-stop(1, #dfdfdf) );

  background:-moz-linear-gradient( center top, #ededed 5%, #dfdfdf 100% );

  filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ededed', endColorstr='#dfdfdf');

  background-color:#ededed;

  -webkit-border-top-left-radius:4px;

  -moz-border-radius-topleft:4px;

  border-top-left-radius:4px;

  -webkit-border-top-right-radius:4px;

  -moz-border-radius-topright:4px;

  border-top-right-radius:4px;

  -webkit-border-bottom-right-radius:4px;

  -moz-border-radius-bottomright:4px;

  border-bottom-right-radius:4px;

  -webkit-border-bottom-left-radius:4px;

  -moz-border-radius-bottomleft:4px;

  border-bottom-left-radius:4px;

  text-indent:0;

  border:1px solid #656565;   /* previous value dcdcdc */

  display:inline-block;

  color:#444444;  /* PV 777777 */

  font-family:arial;

  font-size:12px;

  font-weight:bold;

  font-style:normal;

  margin:0.1em;

  padding:0.3em;

  text-decoration:none;

  text-align:center;

  text-shadow:0px 0px 0px #ffffff;

}



.link_button:hover {

  background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #dfdfdf), color-stop(1, #ededed) );

  background:-moz-linear-gradient( center top, #dfdfdf 5%, #ededed 100% );

  filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#dfdfdf', endColorstr='#ededed');

  background-color:#dfdfdf;

  border: 7777777;

}



.link_button:active {

  position:relative;

  top:1px;

}



input[type="text"] {

  background:#E6E6E6;

  padding: 5px;

  border: solid 1px #fff;

  -webkit-box-shadow: inset 1px 1px 2px 0 #707070;

  -moz-box-shadow: inset 1px 1px 2px 0 #707070;

  box-shadow: inset 1px 1px 2px 0 #707070;

  -webkit-transition: box-shadow 0.3s;

  -moz-transition: box-shadow 0.3s;

  -o-transition: box-shadow 0.3s;

  transition: box-shadow 0.3s;

}



input[type="password"] {

  padding: 5px;

  background:#E6E6E6;

  border: solid 1px #fff;

  -webkit-box-shadow: inset 1px 1px 2px 0 #707070;

  -moz-box-shadow: inset 1px 1px 2px 0 #707070;

  box-shadow: inset 1px 1px 2px 0 #707070;

  -webkit-transition: box-shadow 0.3s;

  -moz-transition: box-shadow 0.3s;

  -o-transition: box-shadow 0.3s;

  transition: box-shadow 0.3s;

}



input[type="submit"] {

  -moz-box-shadow:inset 0px 1px 0px 0px #ffffff;

  -webkit-box-shadow:inset 0px 1px 0px 0px #ffffff;

  box-shadow:inset 0px 1px 0px 0px #ffffff;

  background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #ededed), color-stop(1, #dfdfdf) );

  background:-moz-linear-gradient( center top, #ededed 5%, #dfdfdf 100% );

  filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ededed', endColorstr='#dfdfdf');

  background-color:#ededed;

  -webkit-border-top-left-radius:4px;

  -moz-border-radius-topleft:4px;

  border-top-left-radius:4px;

  -webkit-border-top-right-radius:4px;

  -moz-border-radius-topright:4px;

  border-top-right-radius:4px;

  -webkit-border-bottom-right-radius:4px;

  -moz-border-radius-bottomright:4px;

  border-bottom-right-radius:4px;

  -webkit-border-bottom-left-radius:4px;

  -moz-border-radius-bottomleft:4px;

  border-bottom-left-radius:4px;

  text-indent:0;

  border:1px solid #656565;   /* previous value dcdcdc */

  display:inline-block;

  color:#444444;  /* PV 777777 */

  font-family:arial;

  font-size:12px;

  font-weight:bold;

  font-style:normal;

  margin:0.1em;

  padding:0.3em;

  text-decoration:none;

  text-align:center;

  text-shadow:0px 0px 0px #ffffff;

}



input[type="submit"]:hover {

  background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #dfdfdf), color-stop(1, #ededed) );

  background:-moz-linear-gradient( center top, #dfdfdf 5%, #ededed 100% );

  filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#dfdfdf', endColorstr='#ededed');

  background-color:#dfdfdf;

}



input[type="submit"]:active {

  position:relative;

  top:1px;

}



.shadow {

  -moz-box-shadow:    3px 3px 1px 1px #665;

  -webkit-box-shadow: 3px 3px 1px 1px #665;

  box-shadow:         3px 3px 1px 1px #665;

}



textarea {

  background: #E6E6E6;

  -webkit-border-radius: 4px;

  -moz-border-radius: 4px;

  border-radius: 4px; 

  margin:0.1em;

  padding:0.2em 0.5em 0.2em 0.5em;

}



select {

  border-radius:2px; 

  padding:5px;

  margin:0.1em;

  background-color: #ffffff;

  border: solid 1px #fff;

  -webkit-box-shadow: inset 1px 1px 2px 0 #707070;

  -moz-box-shadow: inset 1px 1px 2px 0 #707070;

  box-shadow: inset 1px 1px 2px 0 #707070;

  -webkit-transition: box-shadow 0.3s;

  -moz-transition: box-shadow 0.3s;

  -o-transition: box-shadow 0.3s;

  transition: box-shadow 0.3s;

  background:#E6E6E6;

  box-shadow: inset 0 1px 2px rgba(0,0,0,0.2); 

  -webkit-appearance:menu-item;

  -moz-appearance:menu-item;

  height:2.3em; 

}



.multi{

  height:7em;

}



#login_holder{

  text-align:center;

  background:#fff;

  margin:0 auto;

  -webkit-border-radius: 7px;

  -moz-border-radius: 7px;

  border-radius: 7px;

  padding:40px;

  width:420px;

  -moz-box-shadow: 5px 5px 5px 5px rgba(68,68,68,0.6);

  -webkit-box-shadow: 5px 5px 5px 5px rgba(68,68,68,0.6);

  box-shadow: 5px 5px 5px 5px rgba(68,68,68,0.6);

}



#login_logo_mast{

  width:530px;

  height:160px;

  background:url(/files/5a0ac02c7a0ce1dacf20fdd672ddf555234b2b8e9a5c8e1a) no-repeat center bottom;

  margin:25px auto;

}



#login_row{



}



#login_td_left{

  text-align:center;

  float:left;

  width:100px;

  padding:5px;

  font-size:16px;

}



#login_td_right input{

  font-size:16px;

  padding:6px;

  border:1px #ccc solid;

}



#footer{

  width:450px;

  margin:20px auto;

  color:#124b7b;

  text-align:center;

  font-size:12px;

}



.login_butt{

  background-color: #1C1C1C;

  color:#000000;

  border:1px #0c2846 solid;

  -moz-border-radius:5px;

  -webkit-border-radius:5px;

  cursor:pointer;

  height:40px;

  width:140px;

  font-size:15px;

}



.label {

  font-weight: bold;

}



#offer_test {

  margin:0px;

  padding:5px;

}



.test_group {

  width: 280px;

  float:left;

  font-size: 13px;

  margin-left:15px;

}



.test_group span{

  font-weight:bold;

  font-size: large;

}



.dropdown-container{

  max-width:900px;

  display:none;

  margin:10 60px;

}



.offer_import{

  font-size:13px;

  height:auto;

  text-align: left;

}



.dropdown-link{

  width:300px;

  font-size:15px;

  color:black;

  text-decoration:none;



}



.dropdown-processed{

  margin-bottom:5px;

  width:100%;

  width:auto;

}



#offer_import{

  width:1024px;

  text-align: left;

}



.offer_us{

  width:430px;

  height:340px;

  float:right;

  padding:8px;

  position:relative;

  background-color:#f1f1f1;

  -webkit-border-radius: 2px;

  -moz-border-radius: 2px;

  border-radius: 2px;

  -moz-box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

  -webkit-box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

  box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

}



.offer_them{

  width:430px;

  height:340px;

  float:left;

  padding:8px;

  margin-bottom:5px;

  position:relative;

  background-color:#f1f1f1;

  -webkit-border-radius: 2px;

  -moz-border-radius: 2px;

  border-radius: 2px;

  -moz-box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

  -webkit-box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

  box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

}



.offer_us2{

  line-height:1.3em;

  width:490px;

  height:465px;

  float:right;

  padding:8px;

  position:relative;

  background-color:#F8F8FF;

  -webkit-border-radius: 2px;

  -moz-border-radius: 2px;

  border-radius: 2px;

  -moz-box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

  -webkit-box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

  box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

}



.offer_them2{

  line-height:1.3em;

  width:490px;

  height:465px;

  float:left;

  padding:8px;

  margin-bottom:5px;

  position:relative;

  background-color:#F8F8FF;

  -webkit-border-radius: 2px;

  -moz-border-radius: 2px;

  border-radius: 2px;

  -moz-box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

  -webkit-box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

  box-shadow: .5px .5px .5px .5px rgba(68,68,68,0.6);

}



.offer_label{

  font-weight:bold;

}



#import_submit{

  position:absolute;

  bottom:10px;

  right:10px;

}



/* pop out boxes */



#dialog{

  padding:2px;

  margin:0px;

  width:auto;

}



.ui-widget {

  font-size:11px;

}



.ui-widget-content {

  background: #F9F9F9;

  color: #222222;

}



.ui-dialog {

  left: 0px;

  outline: 0px none;

  padding: 0px !important;

  position: absolute;

  top: 0px;

}



#success {

  padding: 0px;

  margin: 0px; 

}



.ui-dialog .ui-dialog-content {

  background: none repeat scroll 0 0 transparent;

  border: 0px none;

  overflow: auto;

  position: relative;

  padding: 5 !important;

}



.ui-widget-header {

  background-color: #1C1C1C;

  color: #fff;

}



.ui-dialog .ui-dialog-titlebar {

  position: relative;

  font-size: 1em;

}



/* End Pop Out Boxes */



.tooltip {

  font-size: 14px;

  font-style: italic;

}



.ip_history {

  font-size: 11px;



}



#chart_container{

  background:white;

  width:100%;

}



.footnote {

  font-size: 14px;

  font-weight: bold;

}



/* start of aff sub-menu */



#view_container{

  width:1200px;

  margin:0px;

  padding:0px;

}



#view_container_menu{

  width:250px;

  margin:0px;

  padding:0px;

  float:left;

  text-align: left;

}



.view_container_menu_button{

  width:200px;

  text-align: left;

  float:left;

  font-size: 16px;

}





#view_container_data{

  width:950px;

  margin:0px;

  padding:0px;

  float:left;

  text-align: left;



}

/* end of aff sub-menu */



/* API documentation */



#api_body {

  padding-top:5px;

  margin-top:5px;

  width:1190px; 

  min-height:400px;

  margin-bottom:10px;

  position:relative;

  overflow:hidden;

}



.api_info{

  text-align:left;

  font-size:12px;

  padding-left:10px;

  margin-bottom:25px;

  width:800px;

  float:left;

}



.api_info span{

  text-decoration: italic;

}



#api_left_menu{

  margin:0px 20px 0px 40px;

  font-size:13px;

  padding: 10px 10px 10px 40px;

  width: 250px;

  float: left;

  text-align: left;

  border:1px solid #CCC;

  background-color:#FFF;

}



.api_menu{

  list-style:none;

  padding:0px;

  width:150px;

}



.api_menu div{

  display: block;

  font-weight: bold;

}



.api_menu ul {

  list-style: none;

  padding: 0px;

}



.api_menu ul{

  display: none;

}



.api_menu ul li {

  font-weight: normal;

  cursor: auto;

  background-color: #fff;

  padding: 0px 0px 0px 20px;

}



.api_menu a {

  text-decoration: none;

}



.api_menu a:hover {

  text-decoration: underline;

}



#api_right_menu{

  font-size:12px;

  padding:2px 10px 10px 10px;

  width:800px;

  text-align:left;

  float:left;

  background-color:#FFF;

  border:1px solid #CCC;

}



#api_right_menu h2{

  margin: 10px 0px 10px 0px;

}



.api_target_explain{

  display:none;

  font-size:14px;

  padding: 0px 5px 10px 0px;    

  width:770px;

  text-align:left;

  float:right;

  word-wrap: break-word;

}



.api_parameter{

  margin:0px 0px 20px 20px;

  text-align:left;

}



.api_parameter span{

  font-size:14px;

}



.api_parameter_table{

  width: 100%;

  border-collapse:collapse;

}



.api_parameter_td{

  border:1px solid #CCC;

  padding: 3px;

  font-size:13px;

  margin:0px;

}



.api_parameter_table tr:nth-child(even){

  background-color: #e6e6e6;

}

.api_label{

  font-weight: bold;

  font-size:16px;

}





.OfferTop {



  width: 100%;

  padding:1px;

  margin-left: 70px;



}





.OfferTop_thumbnail {



  width: 100px;

  height: 100px;

  margin-left:20px;

  float:left;

  cursor: pointer;

  padding:1px;

  background-color: #EEEEEE;

  border:1px solid #1C1C1C;

}





.OfferTop_left {



  padding:15px;

  min-width: 400;

  float:left;

  margin-top: 20px;

  margin-left: 30px;

  background-color:#FFFFFF;

  border  : #1C1C1C 1px solid;

}



.OfferTop_right {



  padding:15px;

  float:left;

  margin-left: 20px;



}







/*End API documentation*/



</style>

</head>
<div id="container">
  <center>

    <div id="header">
      <div id="head_left">
        <div id="head_left_1">
          <span class="indent10px"></span>
          <a href="/admin/tickets" title="Internal Tickets Open"><span class="fa fa-comments-o fa-2x admin-notice-ticket"></span></a>&nbsp;277&nbsp;&nbsp;
          <a href="/admin/aff&status=2"title="Affiliates Pending Approval"><span class="fa fa-user-plus fa-2x admin-notice-aff-pend"></span></a>&nbsp;349&nbsp;&nbsp;
          <a href="/admin/select" title="Select Offer Requests"><span class="fa fa-certificate fa-2x admin-notice-select-req"></span></a>&nbsp;9&nbsp;&nbsp;
          <a href="/admin/messages" title="Unread Messages"><span class="fa fa-envelope fa-2x admin-notice-message"></span></a>&nbsp;&nbsp;&nbsp;
          <a href="/admin/aff" title="Affiliate Change Pending Approval"><span class="fa fa-files-o fa-2x admin-notice-aff-change"></span></a>&nbsp;&nbsp;&nbsp;
          <a href="/admin/aff&status=&company=&email=&website=&firstlast=&id=&afftype=&orderby=date_desc&affmanager=&from=&to=&last_status_change=0&tax_form=2" title="Tax Form Change Request"><font color="666666"><span class="fa fa-briefcase fa-2x admin-notices"></font></a> <span>6</span>                                                                   

            <br />
          </div>
        </div>
        <!-- <div id="head_middle"><a href="/admin/"><img class="image_logo" src="files/5a0ac02c7a0ce1dacf20fdd672ddf555234b2b8e9a5c8e1a"></a></div>-->
        <div id="head_middle"><a href="#"><img class="image_logo" src="images/logo.gif"></a></div>
        <div id="head_right"> 
          <B>Logged in as: </B>Jasmine Lee  <B>from</B> 182.71.56.102 (IN)  <a href="/admin/logout">(Logout)</a><BR>
          <span id="lastseen"><b>Currently Active:</b>  Jasmine<br></span>                                                          <span id="world_clocks"><B>Los Angeles:</B> 12:36 AM <B>New York:</B> 3:36 AM <br /> <B>London:</B> 8:36 AM <B>Israel:</B> 10:36 AM <B>Australia:</B> 7:36 PM<br /></span>

          <a href="http://my.afftrack.com/manual/afftrack_getting_started.pdf" target="_BLANK" title="Quick Start Guide"><span class="fa fa-file-text fa-2x notice_inactive"></span></a>&nbsp;&nbsp;&nbsp;
          <a href="http://my.afftrack.com/manual/afftrack_manual.pdf" target="_BLANK" title="User Manual"><span class="fa fa-book fa-2x notice_inactive"></span></a>&nbsp;
          <a href="/admin/change_log" target="_BLANK" title="Change Log"><span class="fa fa-list-alt fa-2x notice_inactive"></span></a>&nbsp;&nbsp;&nbsp;
          <a href="/admin/support" target="_BLANK" title="Submit A Support Ticket"><span class="fa fa-phone fa-2x notice_inactive"></span></a>
          <a title="Currently Active Users" id="currently_active"><span class="fa fa-user fa-2x notice_inactive"></span></a>
          <a title="View World Times" id="world_clock"><span class="fa fa-clock-o fa-2x notice_inactive"></span></a>
          <!-- <a title="View Currently Active Admins" id="current"><span class="fa fa-phone fa-2x notice_inactive"></span></a> -->
        </div>
        <div style="clear: both;" />
        </div>
        <div id="classic_menu">
          <form action="" method="POST">
            <select class="classic_menu_select" name="go2" onchange="this.form.submit()"><option>Affiliates</option>







              <option value="353f9ed5133ae7fa">Add New</option>














              <option value="dd538eb967f70f62">Email Blast</option>











              <option value="03227f6b730ec475">Manage</option>










              <option value="bf0f5f708ebec504">Payments</option>







              <option value="07a041be495ac726">Revenue Report</option>











            </select>
          </form>

          <form action="" method="POST">
            <select class="classic_menu_select" name="go2" onchange="this.form.submit()"><option>Communication</option>



































              <option value="ea88da6a82fb1f3d">Message Center</option>
















              <option value="6a11f1f123810875">Tickets</option>






            </select>
          </form>

          <form action="" method="POST">
            <select class="classic_menu_select" name="go2" onchange="this.form.submit()"><option>Compliance</option>




























              <option value="e804be52a8e2c442">ISP Blacklist/Filter</option>















              <option value="8b80e7e9ccf2fa76">Proxy Manager</option>













              <option value="fa0c0bd46239e592">Unsubscribe List</option>



              <option value="47a4f15817f9a271">Whitelist IP</option>
            </select>
          </form>

          <form action="" method="POST">
            <select class="classic_menu_select" name="go2" onchange="this.form.submit()"><option>Merchants</option>






              <option value="e57a65647436f983">Add New</option>






              <option value="f8186a3109ccf76e">Apply Payments</option>















              <option value="693da7d32f8771be">Invoices</option>


              <option value="4dc88d9b941b8899">IO Builder</option>






              <option value="c4d7063d79b6ac00">Manage</option>
















              <option value="93709c5883680798">Revenue Report</option>










            </select>
          </form>

          <form action="" method="POST">
            <select class="classic_menu_select" name="go2" onchange="this.form.submit()"><option>Offers</option>


              <option value="73ca074754c6c2cb">3rd Party Pixels</option>


              <option value="b1a855c0a001058c">Active Offers Report</option>



              <option value="57a8572b87c9661f">Add New</option>











              <option value="82c6deed7bf212da">Click Report</option>




              <option value="1c16396d4c7f2240">Conversions</option>







              <option value="146f15538589fb6c">Import / Reverse / Hold</option>






              <option value="7fa4bcdf67b07d89">Link Checking</option>




              <option value="3f7368d30451f34a">Manage</option>






              <option value="21d0a568891bd703">Non-Converting Clicks</option>




              <option value="924a09d600899d23">Postback History</option>




              <option value="0b44f89df88214a0">Redirect History</option>


              <option value="ea3ddeb9c5290605">Revenue Report</option>




              <option value="5d786563dfe018e5">Select Requests</option>







              <option value="df1b7b34d3ac9067">Tracking Test</option>



            </select>
          </form>

          <form action="" method="POST">
            <select class="classic_menu_select" name="go2" onchange="this.form.submit()"><option>Other</option>










              <option value="d29fe83982b7562c">Affiliate Referral Program</option>



              <option value="85a6f15e82e9340b">Balance Audit</option>





              <option value="0a73ea04ebec8fab">Commission Check</option>


              <option value="e3ed54482ed39d27">Commission Payments</option>






              <option value="de17ea12ee925019">File Manager</option>




























              <option value="9bb3c026747a9ab8">System Audit</option>




              <option value="ade32c5e1bff53c4">Time Clock</option>




              <option value="e121a0c4655da1f7">Update Payouts</option>

            </select>
          </form>

          <form action="" method="POST">
            <select class="classic_menu_select" name="go2" onchange="this.form.submit()"><option>Prospect</option>




              <option value="aab19f7a2e08efc6">Add</option>






























              <option value="97e0ddf48b844452">Manage</option>























            </select>
          </form>

          <form action="" method="POST">
            <select class="classic_menu_select" name="go2" onchange="this.form.submit()"><option>Settings</option>








              <option value="a0797f136baed610">Admin</option>


              <option value="e34d95d15eb134cf">Affiliate</option>





              <option value="2c1ce9cb563a286c">Brand API</option>


              <option value="6944ef87b8c2fc9b">Branding/Colors</option>






              <option value="7d42c55bf383b741">Domains</option>



              <option value="67a59b8d0d3ea3dd">Email Editor</option>



              <option value="a2fa90bf66ca7897">File Manager</option>





              <option value="59efe9b1823a23f3">IO Editor</option>








              <option value="dca15afdaed7de7b">Merchant</option>



              <option value="d82a8e874338c513">Message Center</option>



              <option value="dde46f6163f95a15">Offer</option>




              <option value="4b8b65cc65887894">Prospect Manager</option>








              <option value="2f4b08428b3da717">System</option>




              <option value="1ddce4d9264504c1">Tickets</option>





            </select>
          </form>

        </div>




        <div id="page_content"><div class="page_top">International URL Tester</div>



          <table width="1150" align="center">

            <tr><td>



                <table>

                  <tr>

                    <form id="form_settings" action="process.php" method="POST">

                      <td><B>Country:</B></td><td> <select name="country"><option value="AF"  >Afghanistan</option><option value="AL"  >Albania</option><option value="DZ"  >Algeria</option><option value="AS"  >American Samoa</option><option value="AD"  >Andorra</option><option value="AO"  >Angola</option><option value="AI"  >Anguilla</option><option value="AQ"  >Antarctica</option><option value="AG"  >Antigua and Barbuda</option><option value="AR"  >Argentina</option><option value="AM"  >Armenia</option><option value="AW"  >Aruba</option><option value="AU"  >Australia</option><option value="AT"  >Austria</option><option value="AZ"  >Azerbaijan</option><option value="BS"  >Bahamas</option><option value="BH"  >Bahrain</option><option value="BD"  >Bangladesh</option><option value="BB"  >Barbados</option><option value="BY"  >Belarus</option><option value="BE"  >Belgium</option><option value="BZ"  >Belize</option><option value="BJ"  >Benin</option><option value="BM"  >Bermuda</option><option value="BT"  >Bhutan</option><option value="BO"  >Bolivia</option><option value="BA"  >Bosnia and Herzegovina</option><option value="BW"  >Botswana</option><option value="BV"  >Bouvet Island</option><option value="BR"  >Brazil</option><option value="IO"  >British Indian Ocean Territory</option><option value="BN"  >Brunei Darussalam</option><option value="BG"  >Bulgaria</option><option value="BF"  >Burkina Faso</option><option value="BI"  >Burundi</option><option value="KH"  >Cambodia</option><option value="CM"  >Cameroon</option><option value="CA"  >Canada</option><option value="CV"  >Cape Verde</option><option value="KY"  >Cayman Islands</option><option value="CF"  >Central African Republic</option><option value="TD"  >Chad</option><option value="CL"  >Chile</option><option value="CN"  >China</option><option value="CO"  >Colombia</option><option value="KM"  >Comoros</option><option value="CG"  >Congo</option><option value="CD"  >Congo</option><option value="CK"  >Cook Islands</option><option value="CR"  >Costa Rica</option><option value="CI"  >Cote D'Ivoire</option><option value="HR"  >Croatia</option><option value="CU"  >Cuba</option><option value="CY"  >Cyprus</option><option value="CZ"  >Czech Republic</option><option value="DK"  >Denmark</option><option value="DJ"  >Djibouti</option><option value="DM"  >Dominica</option><option value="DO"  >Dominican Republic</option><option value="EC"  >Ecuador</option><option value="EG"  >Egypt</option><option value="SV"  >El Salvador</option><option value="GQ"  >Equatorial Guinea</option><option value="ER"  >Eritrea</option><option value="EE"  >Estonia</option><option value="ET"  >Ethiopia</option><option value="EU"  >Europe</option><option value="FK"  >Falkland Islands (Malvinas)</option><option value="FO"  >Faroe Islands</option><option value="FJ"  >Fiji</option><option value="FI"  >Finland</option><option value="FR"  >France</option><option value="GF"  >French Guiana</option><option value="PF"  >French Polynesia</option><option value="GA"  >Gabon</option><option value="GM"  >Gambia</option><option value="GE"  >Georgia</option><option value="DE"  >Germany</option><option value="GH"  >Ghana</option><option value="GI"  >Gibraltar</option><option value="GR"  >Greece</option><option value="GL"  >Greenland</option><option value="GD"  >Grenada</option><option value="GP"  >Guadeloupe</option><option value="GU"  >Guam</option><option value="GT"  >Guatemala</option><option value="GN"  >Guinea</option><option value="GW"  >Guinea-Bissau</option><option value="GY"  >Guyana</option><option value="HT"  >Haiti</option><option value="HM"  >Heard Island and McDonald Islands</option><option value="HN"  >Honduras</option><option value="HK"  >Hong Kong</option><option value="HU"  >Hungary</option><option value="IS"  >Iceland</option><option value="IN"  >India</option><option value="ID" selected="selected" >Indonesia</option><option value="IR"  >Iran</option><option value="IQ"  >Iraq</option><option value="IE"  >Ireland</option><option value="IL"  >Israel</option><option value="IT"  >Italy</option><option value="JM"  >Jamaica</option><option value="JP"  >Japan</option><option value="JO"  >Jordan</option><option value="KZ"  >Kazakstan</option><option value="KE"  >Kenya</option><option value="KI"  >Kiribati</option><option value="KW"  >Kuwait</option><option value="KG"  >Kyrgyzstan</option><option value="LA"  >Lao</option><option value="LV"  >Latvia</option><option value="LB"  >Lebanon</option><option value="LS"  >Lesotho</option><option value="LR"  >Liberia</option><option value="LY"  >Libyan Arab Jamahiriya</option><option value="LI"  >Liechtenstein</option><option value="LT"  >Lithuania</option><option value="LU"  >Luxembourg</option><option value="MO"  >Macau</option><option value="MK"  >Macedonia</option><option value="MG"  >Madagascar</option><option value="MW"  >Malawi</option><option value="MY"  >Malaysia</option><option value="MV"  >Maldives</option><option value="ML"  >Mali</option><option value="MT"  >Malta</option><option value="MH"  >Marshall Islands</option><option value="MQ"  >Martinique</option><option value="MR"  >Mauritania</option><option value="MU"  >Mauritius</option><option value="YT"  >Mayotte</option><option value="MX"  >Mexico</option><option value="FM"  >Micronesia</option><option value="MD"  >Moldova</option><option value="MC"  >Monaco</option><option value="MN"  >Mongolia</option><option value="ME"  >Montenegro</option><option value="MS"  >Montserrat</option><option value="MA"  >Morocco</option><option value="MZ"  >Mozambique</option><option value="MM"  >Myanmar</option><option value="NA"  >Namibia</option><option value="NR"  >Nauru</option><option value="NP"  >Nepal</option><option value="NL"  >Netherlands</option><option value="AN"  >Netherlands Antilles</option><option value="NC"  >New Caledonia</option><option value="NZ"  >New Zealand</option><option value="NI"  >Nicaragua</option><option value="NE"  >Niger</option><option value="NG"  >Nigeria</option><option value="NU"  >Niue</option><option value="NF"  >Norfolk Island</option><option value="KP"  >North Korea</option><option value="MP"  >Northern Mariana Islands</option><option value="NO"  >Norway</option><option value="OM"  >Oman</option><option value="PK"  >Pakistan</option><option value="PW"  >Palau</option><option value="PS"  >Palestinian Territory</option><option value="PA"  >Panama</option><option value="PG"  >Papua New Guinea</option><option value="PY"  >Paraguay</option><option value="PE"  >Peru</option><option value="PH"  >Philippines</option><option value="PL"  >Poland</option><option value="PT"  >Portugal</option><option value="PR"  >Puerto Rico</option><option value="QA"  >Qatar</option><option value="RE"  >Reunion</option><option value="RO"  >Romania</option><option value="RU"  >Russian Federation</option><option value="RW"  >Rwanda</option><option value="KN"  >Saint Kitts and Nevis</option><option value="LC"  >Saint Lucia</option><option value="VC"  >Saint Vincent and the Grenadines</option><option value="WS"  >Samoa</option><option value="SM"  >San Marino</option><option value="ST"  >Sao Tome and Principe</option><option value="SA"  >Saudi Arabia</option><option value="SN"  >Senegal</option><option value="RS"  >Serbia</option><option value="SC"  >Seychelles</option><option value="SL"  >Sierra Leone</option><option value="SG"  >Singapore</option><option value="SK"  >Slovakia</option><option value="SI"  >Slovenia</option><option value="SB"  >Solomon Islands</option><option value="SO"  >Somalia</option><option value="ZA"  >South Africa</option><option value="KR"  >South Korea</option><option value="ES"  >Spain</option><option value="LK"  >Sri Lanka</option><option value="SD"  >Sudan</option><option value="SR"  >Suriname</option><option value="SZ"  >Swaziland</option><option value="SE"  >Sweden</option><option value="CH"  >Switzerland</option><option value="SY"  >Syrian Arab Republic</option><option value="TW"  >Taiwan</option><option value="TJ"  >Tajikistan</option><option value="TH"  >Thailand</option><option value="TG"  >Togo</option><option value="TK"  >Tokelau</option><option value="TO"  >Tonga</option><option value="TT"  >Trinidad and Tobago</option><option value="TN"  >Tunisia</option><option value="TR"  >Turkey</option><option value="TM"  >Turkmenistan</option><option value="TC"  >Turks and Caicos Islands</option><option value="TV"  >Tuvalu</option><option value="UG"  >Uganda</option><option value="UA"  >Ukraine</option><option value="AE"  >United Arab Emirates</option><option value="UK"  >United Kingdom</option><option value="TZ"  >United Republic of Tanzania</option><option value="US"  >United States</option><option value="UM"  >United States Minor Outlying Islands</option><option value="UY"  >Uruguay</option><option value="UZ"  >Uzbekistan</option><option value="VU"  >Vanuatu</option><option value="VA"  >Vatican City State</option><option value="VE"  >Venezuela</option><option value="VN"  >Vietnam</option><option value="VG"  >Virgin Islands British</option><option value="VI"  >Virgin Islands US</option><option value="WF"  >Wallis and Futuna</option><option value="YE"  >Yemen</option><option value="ZM"  >Zambia</option><option value="ZW"  >Zimbabwe</option></select></td></tr>





                    <tr><td><B>Timeout:</B></td><td>

                        <select name="timeout">

                          <option value="15" >15 Seconds</option>

                          <option value="30" selected="selected" >30 Seconds</option>

                          <option value="45" >45 Seconds</option>

                          <option value="60" >60 Seconds</option>

                          <option value="75" >75 Seconds</option>

                          <option value="90" >90 Seconds</option>



                        </select>

                    </td></tr>



                    <tr><td><B>Device:</B></td><td><select name="device">

                          <option value="droid_2" >Android OS 2</option>

                          <option value="droid_3" >Android OS 3</option>

                          <option value="droid_4" >Android OS 4</option>

                          <option value="droid_5"  selected="selected">Android OS 5</option>

                          <option value="ipad_4" >iPad OS 4</option>

                          <option value="ipad_5" >iPad OS 5</option>

                          <option value="ipad_6" >iPad OS 6</option>

                          <option value="ipad_7" >iPad OS 7</option>

                          <option value="ipad_8" >iPad OS 8</option>

                          <option value="ipad_9" >iPad OS 9</option>

                          <option value="iphone_4" >iPhone OS 4</option>

                          <option value="iphone_5" >iPhone OS 5</option>

                          <option value="iphone_6" >iPhone OS 6</option>

                          <option value="iphone_7" >iPhone OS 7</option>

                          <option value="iphone_8" >iPhone OS 8</option>

                          <option value="iphone_9" >iPhone OS 9</option>

                          <option value="ipod_4" >iPod OS 4</option>

                          <option value="ipod_5" >iPod OS 5</option>

                          <option value="ipod_6" >iPod OS 6</option>

                          <option value="chrome" >Windows - Chrome</option>

                          <option value="firefox" >Windows - Firefox 40</option>

                          <option value="ie" >Windows - Internet Explorer</option>



                    </select> </td></tr>



                    <td><B>URL:</B></td><td><input type="text" name="url" value="http://apitrx.com/click?aid=65&linkid=T987765877053&s1={transaction_id}&s2={affiliate_id}-{source}" size="100"><input type="button" value="surf" name="surf"  id="surf"></tr>

                  </form>

                </table>





                <B><h2>Offer Redirects:</B></h2>

                <div id="offer_redirects">
                <ul>

                  <li>http://apitrx.com/click?aid=65&linkid=T987765877053&s1=%7Btransaction_id%7D&s2=%7Baffiliate_id%7D-%7<BR>Bsource%7D</li>

                  <li>http://apitrx.com/jump?url=888cd36d732d9f04131435f24fe06adfbabf4d617fff3d052e1f74acef2a4b876d1dc764c<BR>933ae2d5f27e13b5f222008f43868c7346ae7a0db398e5190f471e9f5738dea9d9cc87ea788d26b275f7b92d36d23f67c4b3<BR>5dd415946f5697adc88a032630022bdde517b839a4adc41c0e6</li>

                  <li>http://www.mediamob.in/?a=50hyfko&b=id18dz0&s2=&click=8387d2067107e58a48413e6f04fa0ce5&idfa=</li>

                  <li>http://app.appsflyer.com/com.famelive?pid=opera_response_int&c=operaindonesiaincent&clickid=67912276<BR>33&idfa=&sha1_udid=&imei=&sha1_android_id=&af_siteid=6180_null</li>

                  <li>market://details?id=com.famelive&referrer=af_tranid%3Dcom.famelive_1086c2f1-b55d-4604-a781-5c9136e84<BR>329%26sha1_android_id%3D%26pid%3Dopera_response_int%26app-id%3Dcom.famelive%26imei%3D%26idfa%3D%26cl<BR>ickid%3D6791227633%26af_siteid%3D6180_null%26sha1_udid%3D%26c%3Doperaindonesiaincent</li>

                </ul>      </div>



                <B><h2>Final Page Source Code:</B></h2>

                <center> <textarea id="final_page" rows=20 cols=125>
                    <html><head><meta http-equiv="refresh" content="0;url=http://www.mediamob.in/?a=50hyfko&amp;b=id18dz0&amp;s2=&amp;click=8387d2067107e58a48413e6f04fa0ce5&amp;idfa="> </head><body></body></html></textarea></center>


                <B><h2>Screenshot:</B></h2>

<div id="screenshot">
                <center><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAJYCAYAAACadoJwAAAACXBIWXMAAAsTAAALEwEAmpwYAAAHXElEQVR4nO3BMQEAAADCoPVPbQZ/oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+A1ALAAFujETzAAAAAElFTkSuQmCC"  style="height:800x;max-width:600px;width: expression(this.width > 600 ? 600: true);"><BR></center>



</div>


                <BR>



            </td></tr>

        </table></div>
        <br /><br /><br />
      </center>
    </div>
</html>
