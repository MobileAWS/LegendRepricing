<?php require_once('../URLResolver.php');
include_once('config.php');
/*******************************************************************************
* Copyright (c) 2011-2014 by Matt Wright
* https://github.com/mattwright/URLResolver.php
*
* Licensed under The MIT License
* See URLResolver.php for full license text
*******************************************************************************/

/*
if (count($argv) != 2 || !preg_match('/^https?:\/\//i', $argv[1])) {
	print "You must supply a URL:\n  ./resolve_url.php http://goo.gl/0GMP1\n";
	exit;
}
 */

$url='';
$listurls=array();
$final_page='';
if($_POST && $_POST['url'] &&  $_POST['device'] && $_POST['country'] && isset($device[$_POST['device']]) && isset($country[$_POST['country']]))
{
  error_log("USing ".$device[$_POST['device']].' '.$country[$_POST['country']], 3, "/var/tmp/mineerrors.log");
//$url='http://trk.rainydaymarketing.com/aff_c?offer_id=25363&aff_id=3324&aff_sub=xapnt1x&source=xapnt17x';
//$url='http://trk.rainydaymarketing.com/click?aid=3324&linkid=B109449&s1=211144412254328&s2=xapnt17x&google_aid=xapnt6x';
$url=$_POST['url'];
///$url='http://apitrx.com/click?aid=65&linkid=T987765877053&s1={transaction_id}&s2={affiliate_id}-{source}';
$resolver = new URLResolver();
$resolver->isDebugMode(false);
//$resolver->setUserAgent('Mozilla/5.0 (compatible; URLResolver.php/1.0; +https://github.com/mattwright/URLResolver.php)');
//$resolver->setUserAgent('Mozilla/5.0 (iPad; CPU OS 9_0 like Mac OS X) AppleWebKit/601.1.16 (KHTML, like Gecko) Version/8.0 Mobile/13A171a Safari/600.1.4');
//$resolver->setUserAgent('Mozilla/5.0 (Linux; Android 5.0; Nexus 5 Build/LPX13D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.102 Mobile Safari/537.36');
$resolver->setUserAgent($device[$_POST['device']]);
$resolver->setUserproxy($country[$_POST['country']]);
//$resolver->setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 9_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13C75 Safari/601.1');
//$resolver->setCookieJar('/tmp/url_resolver.cookies');
$resolver->setMaxRedirects(100); # Defaults to 10

$resolver->setMaxResponseDataSize(1000000);
$resolver->setRequestTimeout(500);
$result=$resolver->resolveURL($url);
$final_page=$result->getURL();
$text='';
foreach($listurls as $val)
{
 $text.='<li>'.$val.'</li>';
}
echo json_encode(array('offer_redirects'=>$text,'screenshot'=>'nothing','final_page'=>$final_page));
}
else
{
echo json_encode(array('offer_redirects'=>'nothing','screenshot'=>'nothing','final_page'=>'nothing'));
}
//echo 'FINALLLLLLLLLLLLLLLLLl';
//echo $result->getURL();
//print_r($result);
//print_r($result->getcollect());
