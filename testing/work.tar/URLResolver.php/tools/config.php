<?php
$country=array('CU'=>'200.0.27.62:8080','CY'=>'213.149.183.141:9064','CH'=>'120.198.231.85:8080','BR'=>'186.226.190.46:8080','ID'=>'202.159.42.246:80','NZ'=>'202.50.176.212:8080','US'=>'198.148.15.237:8000',
'TW'=>'180.218.126.225:8080','AU'=>'203.122.213.51:8080');
$device=array('droid_5'=>'Mozilla/5.0 (Linux; Android 5.0; Nexus 5 Build/LPX13D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.102 Mobile Safari/537.36','iphone_9'=>'Mozilla/5.0 (iPhone; CPU iPhone OS 9_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13C75 Safari/601.1');
//if($country['ss'])
 // echo 'ddd';
